import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from skimage import measure
import plotly.graph_objects as go
import dash
import dash_core_components as dcc
import dash_html_components as html


np.seterr(divide='ignore', invalid='ignore')

feature = 'attacktype1_txt'
feature2 = 'targtype1_txt'
XboardScale = 400
YboardScale = 300


n_groups = 4

N = 20

np.seterr(divide='ignore', invalid='ignore')

# load the data_gtdset from data_gtd server
data_gtd = pd.read_csv('gtd.csv', encoding='ISO-8859-1')
data_gtd = data_gtd[data_gtd['latitude'].notna()]
data_gtd = data_gtd[data_gtd['longitude'].notna()]
# Prepcocessing of data_gtd, dropping data_gtd with missing value
data_gtd = data_gtd.dropna(axis='columns')
# print(data_gtd[feature])
data_gtd = data_gtd[data_gtd['country_txt'] == 'United States'].reset_index()
data_gtd.rename(columns={'latitude': 'Y', 'longitude': 'X'}, inplace=True)

# Dataset of SF crime
data_SF = pd.read_csv('SF_crime.csv')
data_SF = data_SF.dropna()
data_SF['Date'] = data_SF['Date'].astype(str)
data_SF['Time'] = data_SF['Time'].astype(str)
data_SF['Hour'] = [x[:2] for x in data_SF['Time']]
data_SF['Hour'] = data_SF['Hour'].astype(int)

# Get data for plotting in advance
def get_df(dataset, feature, n_groups):
    df_m = []
    kinds = dataset[feature].unique().tolist()
    count = []
    for t in kinds:
        n = len(dataset[dataset[feature] == t])
        count.append(n)
    most_type = []
    for i in range(n_groups):
        m = count.index(max(count))
        most_type.append(kinds[m])
        count[m] = 0
    # print(feature, most_type)
    df_1 = dataset[dataset[feature] == most_type[0]].sample(n=N).reset_index()
    df_m.append(df_1)
    df_all = df_1
    for k in np.arange(1, n_groups):
        df_sub = dataset[dataset[feature] == most_type[k]].sample(n=N).reset_index()
        df_all = df_all.append(df_sub, ignore_index=True)
        df_m.append(df_sub)

    # potential, x, y = setBoundary(df_all=df_all, df_m=df_m)

    return df_all, df_m, most_type






def pointsInitial(dataframe):
    # X = np.random.randint(XboardScale / 10, XboardScale * 9 / 10, size=(N, 1))
    # Y = np.random.randint(YboardScale / 10, YboardScale * 9 / 10, size=(N, 1))
    # x_min = df_1['X'].min()
    # x_max = df_1['X'].max()
    # y_min = df_1['Y'].min()
    # y_max = df_1['Y'].max()
    # step_x = (x_max - x_min) / XboardScale
    # step_y = (y_max - y_min) / YboardScale
    x_line = dataframe['X'].tolist()
    y_line = dataframe['Y'].tolist()
    return [x_line, y_line]


def setBoundary(df_all,
    df_m,
    R2Node,
    R1Node,
    R0Node,
    R1Edge,
    R0Edge,
    R0Node2,
    weightNode,
    weightEdge,
    weight2,
    buffer,
    pointsOnLine):
    # initialization
    xLists = np.zeros([N, n_groups], dtype=float)
    yLists = np.zeros([N, n_groups], dtype=float)
    potentials = np.zeros([XboardScale, YboardScale, n_groups], dtype=float)

    # Create data set
    x_min = df_all['X'].min()
    x_max = df_all['X'].max()
    y_min = df_all['Y'].min()
    y_max = df_all['Y'].max()
    step_x = (x_max - x_min) / (XboardScale * 0.8)
    step_y = (y_max - y_min) / (YboardScale * 0.8)

    for group in range(n_groups):
        line1 = pointsInitial(df_m[group])
        xList = []
        yList = []
        for x1 in line1[0]:
            increment = int(((x1 - x_min) / step_x) + 1 + XboardScale * 0.1)
            xList.append(increment)
        for y1 in line1[1]:
            increment = int(((y1 - y_min) / step_y) + 1 + YboardScale * 0.1)
            yList.append(increment)
        xList = np.asarray(xList)
        yList = np.asarray(yList)
        # pointsLoc = pointsInitial(df_all)
        xLists[:, group] = xList
        yLists[:, group] = yList

    # Calculate center point
    xCenter = np.mean(xLists[:, 0])
    yCenter = np.mean(yLists[:, 0])
    indexSorted = sorted(range(len(xLists[:, 0])),
                         key=lambda k: (xLists[k, 0] - xCenter) ** 2 + (yLists[k, 0] - yCenter) ** 2)
    xLists[:, 0] = xLists[indexSorted, 0]
    yLists[:, 0] = yLists[indexSorted, 0]

    # # Plot scattering
    # plt.figure(1)
    # for group in range(n_groups):
    #     plt.plot(xLists[:, group], yLists[:, group], marker='o', markersize=5, color=colors[group], linestyle='')

    # Calcualte potential based on data
    for group in range(n_groups):
        xList = xLists[:, group]
        yList = yLists[:, group]
        xList2 = []
        yList2 = []
        for other_group in range(n_groups):
            if other_group != group:
                xList2 = np.append(xList2, xLists[:, other_group])
                yList2 = np.append(yList2, yLists[:, other_group])

        potentials[:, :, group] = potentialCal(xList, yList, xList2, yList2,     R2Node,
    R1Node,
    R0Node,
    R1Edge,
    R0Edge,
    R0Node2,
    weightNode,
    weightEdge,
    weight2,
    buffer,
    pointsOnLine)

    return potentials, xLists, yLists


def potentialCal(xList, yList, xList2, yList2,
                 R2Node,
                 R1Node,
                 R0Node,
                 R1Edge,
                 R0Edge,
                 R0Node2,
                 weightNode,
                 weightEdge,
                 weight2,
                 buffer,
                 pointsOnLine
                 ):
    N = len(xList)
    M = len(xList2)
    potential = np.zeros([XboardScale, YboardScale], dtype=float)

    edgeList = [[xList[1], yList[1], xList[0], yList[0]]]

    for i in range(2, N):
        tempXList = xList[0: i]
        tempYList = yList[0: i]
        indexNearest = sorted(range(i), key=lambda k: (xList[i] - tempXList[k]) ** 2 + (yList[i] - tempYList[k]) ** 2)
        j = indexNearest[0]
        edgeList.append([xList[i], yList[i], xList[j], yList[j]])

    edgePointList = []
    for i in range(len(edgeList)):
        edgePointList.append([[edgeList[i][0] + (edgeList[i][2] - edgeList[i][0]) * k / (pointsOnLine),
                               edgeList[i][1] + (edgeList[i][3] - edgeList[i][1]) * k / pointsOnLine] for k in
                              range(pointsOnLine + 1)])
        for j in range(1, len(edgePointList[i]) - 1):
            for k in range(len(xList2)):
                if edgePointList[i][j][0] < xList2[k] + R0Node2 and edgePointList[i][j][0] > xList2[k] - R0Node2 and \
                        edgePointList[i][j][1] < yList2[k] + R0Node2 and edgePointList[i][j][1] > yList2[k] - R0Node2:
                    v = np.array([edgePointList[i][j][0] - xList2[k], edgePointList[i][j][1] - yList2[k]])
                    vLength = (v ** 2).sum() ** 0.5
                    vUnit = v / vLength
                    edgePointList[i][j][0] = xList2[k] + (vUnit[0]) * buffer
                    edgePointList[i][j][1] = yList2[k] + (vUnit[1]) * buffer

    for i in range(len(edgeList)):
        print(i)
        edgePointList.append([[edgeList[i][0] + (edgeList[i][2] - edgeList[i][0]) * k / (pointsOnLine),
                               edgeList[i][1] + (edgeList[i][3] - edgeList[i][1]) * k / pointsOnLine] for k in
                              range(pointsOnLine + 1)])
        for j in range(0, len(edgePointList[i])):
            if j == 0 or j == len(edgePointList[i]) - 1:
                R1 = R1Node
                R0 = R0Node
                weight = weightNode
            else:
                R1 = R1Edge
                R0 = R0Edge
                weight = weightEdge
            for x in range(np.int_(max(0, edgePointList[i][j][0] - R1)),
                           np.int_(min(edgePointList[i][j][0] + R1, XboardScale))):
                for y in range(np.int_(max(0, edgePointList[i][j][1] - R1)),
                               np.int_(min(edgePointList[i][j][1] + R1, YboardScale))):
                    disNode = np.sqrt((1.0 * x - edgePointList[i][j][0]) ** 2 + (1.0 * y - edgePointList[i][j][1]) ** 2)
                    if disNode < R1:
                        if disNode < R0:
                            potential[x, y] += weight
                        else:
                            potential[x, y] += weight * (R1 - disNode) ** 2 / (R1 - R0) ** 2

                        # for wallindex in range(M):
                        #     x_wall = xList2[wallindex]
                        #     y_wall = yList2[wallindex]
                        #
                        #     if np.abs(x_wall - x) < R2Node and np.abs(y_wall - y) < R2Node:
                        #         dis = np.sqrt((1.0 * x - x_wall) ** 2 + (1.0 * y - y_wall) ** 2)
                        #         if dis < R2Node:
                        #             potential[x, y] -= weight2 * (1 - (dis / R2Node) ** 2)

                        if potential[x, y] < 0:
                            potential[x, y] = 0

                        if potential[x, y] > 15:
                            potential[x, y] = 15

                        # print(potential[x, y])

        # for j in range(len(edgePointList[i])):
        #     plt.figure(1)
        #     plt.plot(edgePointList[i][j][0], edgePointList[i][j][1],  color = 'black', marker = 'o')
    # plt.gca().invert_yaxis()
    potential[potential < 0] = 0
    # fig, ax = plt.subplots()
    # ax.imshow(np.transpose(potential))
    # print(potential)
    # # Plot coutour for two sets
    # contour = measure.find_contours(np.transpose(potential), 1)
    # for n, contour in enumerate(contour):
    #     plt.figure(1)
    #     plt.plot(contour[:, 1], contour[:, 0], linewidth=2)

    return potential




df_all_11, df_m_11, most_type_11 = get_df(dataset=data_gtd, feature='attacktype1_txt', n_groups=n_groups)
potential_11, x_11, y_11 = setBoundary(df_all=df_all_11, df_m=df_m_11,
R2Node = 3.0,
R1Node = 14.0,
R0Node = 4.0,
R1Edge = 12.0,
R0Edge = 2.5,
R0Node2 = 10.0,
weightNode = 1,
weightEdge = 0.6,
weight2 = 0.3,
buffer = 11,
pointsOnLine = 100)

df_all = df_all_11
df_m = df_m_11
types = most_type_11
potentials = potential_11


print(potential_11)
x = x_11
y = y_11

x_min = df_all['X'].min()
x_max = df_all['X'].max()
gap_x = x_max - x_min
y_min = df_all['Y'].min()
y_max = df_all['Y'].max()
gap_y = y_max - y_min
x_line = [x_min, x_min + gap_x * 0.25, x_min + gap_x * 0.5, x_min + gap_x * 0.75, x_max]
y_line = [y_min, y_min + gap_y * 0.25, y_min + gap_y * 0.5, y_min + gap_y * 0.75, y_max]

traces = []
colors_contour = ['blue', 'red', 'green', 'orange']

print(dict(start=0, end=15, size=9))

for i in range(n_groups):
    z = potentials[:, :, i]
    x1 = x[:, i].tolist()
    y1 = y[:, i].tolist()
    trace1 = go.Contour(z=z, colorscale=[[0, 'rgba(256,256,256, 0)'], [0.8, colors_contour[i]], [1, 'rgba(0,0,0,0)']],
                        contours=dict(start=1, end=15, size=14),
                        opacity=0.5, showscale=False,
                        reversescale=False)
    trace2 = go.Scatter(x=y1, y=x1, opacity=0.8, mode='markers', name=types[i],
                        marker=dict(size=15, color=colors_contour[i]))
    traces.append(trace1)
    traces.append(trace2)
layout = {
    'title': 'San Francisco Crime record in 2016 by twisted middle points',
    'height': 800,
    'xaxis': {
        'title': 'Longitude',
        'ticks': 'outside',
        'ticktext': x_line,
        'tickvals': [(k - 1) * YboardScale / (5 - 1) for k in range(1, 6)],
        # 'ticktext': [str(df_all['Y'].min()), str(df_all['Y'].max())],
        "tickfont": {
            "size": 11,
            "color": "rgb(107, 107, 107)"
        },
        "tickwidth": 1,
        "showticklabels": True
    },
    'yaxis': {
        'title': 'Latitude',
        'ticks': 'outside',
        'ticktext': y_line,
        'tickvals': [(k - 1) * XboardScale / (5 - 1) for k in range(1, 6)],
        "tickfont": {
            "size": 11,
            "color": "rgb(107, 107, 107)"
        },
        "tickwidth": 1,
        "showticklabels": True
    },
}
fig1 = go.Figure(data=traces, layout=layout)

fig1.update_layout(
    plot_bgcolor='rgba(0, 0, 0, 0)',
    paper_bgcolor='rgba(0, 0, 0, 0)',
)
fig1.show()

plt.show()