import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import normalize
from skimage import measure
import pandas as pd
from bubbleBoundary_twisted_middle_points import *
from bubbleBoundary3_new_input import *
import plotly.graph_objects as go
import dash
import dash_core_components as dcc
import dash_html_components as html
import urllib.request as req
from dash.dependencies import Input, Output
from numpy import genfromtxt

# my_data = genfromtxt('my_file.csv', delimiter=',')

np.seterr(divide='ignore', invalid='ignore')

feature = 'attacktype1_txt'
feature2 = 'targtype1_txt'
XboardScale = 400
YboardScale = 300
N = 20
# M = 20
RNode = 3
R2Node = 2.0
R1Node = 8.0
R0Node = 1.0
R1Edge = 3.0
R0Edge = 1
R0Node2 = 3.0
weightNode = 1
weightEdge = 1
weight2 = 0.3
buffer = 4
pointsOnLine = 60

n_groups = 4

np.seterr(divide='ignore', invalid='ignore')

# load the data_gtdset from data_gtd server
data_gtd = pd.read_csv('gtd.csv', encoding='ISO-8859-1')
data_gtd = data_gtd[data_gtd['latitude'].notna()]
data_gtd = data_gtd[data_gtd['longitude'].notna()]
# Prepcocessing of data_gtd, dropping data_gtd with missing value
data_gtd = data_gtd.dropna(axis='columns')
# print(data_gtd[feature])
data_gtd = data_gtd[data_gtd['country_txt'] == 'United States'].reset_index()
data_gtd.rename(columns={'latitude': 'Y', 'longitude': 'X'}, inplace=True)

# Dataset of SF crime
data_SF = pd.read_csv('SF_crime.csv')
data_SF = data_SF.dropna()
data_SF['Date'] = data_SF['Date'].astype(str)
data_SF['Time'] = data_SF['Time'].astype(str)
data_SF['Hour'] = [x[:2] for x in data_SF['Time']]
data_SF['Hour'] = data_SF['Hour'].astype(int)


# Get data for plotting in advance
def get_df(dataset, feature, n_groups):
    df_m = []
    kinds = dataset[feature].unique().tolist()
    count = []
    for t in kinds:
        n = len(dataset[dataset[feature] == t])
        count.append(n)
    most_type = []
    for i in range(n_groups):
        m = count.index(max(count))
        most_type.append(kinds[m])
        count[m] = 0
    print(feature, most_type)
    df_1 = dataset[dataset[feature] == most_type[0]].sample(n=N).reset_index()
    df_m.append(df_1)
    df_all = df_1
    for k in np.arange(1, n_groups):
        df_sub = dataset[dataset[feature] == most_type[k]].sample(n=N).reset_index()
        df_all = df_all.append(df_sub, ignore_index=True)
        df_m.append(df_sub)

    # potential, x, y = setBoundary(df_all=df_all, df_m=df_m)

    return df_all, df_m, most_type


# Data_gtd: 'attacktype1_txt'
df_all_11, df_m_11, most_type_11 = get_df(dataset=data_gtd, feature='attacktype1_txt', n_groups=n_groups)
potential_11 = np.zeros([XboardScale, YboardScale, n_groups], dtype=float)
potential_A_11 = np.zeros([XboardScale, YboardScale, n_groups], dtype=float)

# Data_gtd: 'targtype1_txt'
df_all_12, df_m_12, most_type_12 = get_df(dataset=data_gtd, feature='targtype1_txt',
                                          n_groups=n_groups)
potential_12 = np.zeros([XboardScale, YboardScale, n_groups], dtype=float)
potential_A_12 = np.zeros([XboardScale, YboardScale, n_groups], dtype=float)
# Data_SF: 'Category'
df_all_21, df_m_21, most_type_21 = get_df(dataset=data_SF, feature='Category',
                                          n_groups=n_groups)
potential_21 = np.zeros([XboardScale, YboardScale, n_groups], dtype=float)
potential_A_21 = np.zeros([XboardScale, YboardScale, n_groups], dtype=float)
# Data_SF: 'Slot'
# Midnight Slot
data_1 = data_SF[(data_SF['Hour'] <= 5) & (data_SF['Hour'] >= 0)]
df_1 = data_1.sample(n=N).reset_index()
df_1['Slot'] = 'Midnight'
df_all_22 = df_1
# Morning Slot
data_1 = data_SF[(data_SF['Hour'] <= 11) & (data_SF['Hour'] >= 6)]
df_2 = data_1.sample(n=N).reset_index()
df_2['Slot'] = 'Morning'
df_all_22 = df_all_22.append(df_2, ignore_index=True)
# Afternoon Slot
data_1 = data_SF[(data_SF['Hour'] <= 17) & (data_SF['Hour'] >= 12)]
df_3 = data_1.sample(n=N).reset_index()
df_3['Slot'] = 'Afternoon'
df_all_22 = df_all_22.append(df_3, ignore_index=True)
# Evening Slot
data_1 = data_SF[(data_SF['Hour'] <= 23) & (data_SF['Hour'] >= 18)]
df_4 = data_1.sample(n=N).reset_index()
df_4['Slot'] = 'Evening'
df_all_22 = df_all_22.append(df_4, ignore_index=True)
df_m_22 = [df_1, df_2, df_3, df_4]
potential_22 = np.zeros([XboardScale, YboardScale, n_groups], dtype=float)
potential_A_22 = np.zeros([XboardScale, YboardScale, n_groups], dtype=float)
most_type_22 = ['Midnight', 'Morning', 'Afternoon', 'Evening']
for i in range(4):
    potential_11[:, :, i] = genfromtxt('potential_11_' + str(i) + '.csv')
    potential_12[:, :, i] = genfromtxt('potential_12_' + str(i) + '.csv')
    potential_21[:, :, i] = genfromtxt('potential_21_' + str(i) + '.csv')
    potential_22[:, :, i] = genfromtxt('potential_22_' + str(i) + '.csv')
    potential_A_11[:, :, i] = genfromtxt('potential_A_11_' + str(i) + '.csv')
    potential_A_12[:, :, i] = genfromtxt('potential_A_12_' + str(i) + '.csv')
    potential_A_21[:, :, i] = genfromtxt('potential_A_21_' + str(i) + '.csv')
    potential_A_22[:, :, i] = genfromtxt('potential_A_22_' + str(i) + '.csv')

x_11 = genfromtxt('x_11.csv')
y_11 = genfromtxt('y_11.csv')
x_12 = genfromtxt('x_12.csv')
y_12 = genfromtxt('y_12.csv')
x_21 = genfromtxt('x_21.csv')
y_21 = genfromtxt('y_21.csv')
x_22 = genfromtxt('x_22.csv')
y_22 = genfromtxt('y_22.csv')
x_A_11 = genfromtxt('x_A_11.csv')
y_A_11 = genfromtxt('y_A_11.csv')
x_A_12 = genfromtxt('x_A_12.csv')
y_A_12 = genfromtxt('y_A_12.csv')
x_A_21 = genfromtxt('x_A_21.csv')
y_A_21 = genfromtxt('y_A_21.csv')
x_A_22 = genfromtxt('x_A_22.csv')
y_A_22 = genfromtxt('y_A_22.csv')
# data_1 = data_SF[data_SF['Date'].str.startswith('01') == True]
# # print(len(data_1))
# data_1_sub = data_1.sample(n=7).reset_index()
# # print(data_1_sub)
# Months = ['02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']
# for m in Months:
#     data_m = data_SF[data_SF['Date'].str.startswith(m) == True]
#     data_m_sub = data_m.sample(n=7).reset_index()
#     data_1_sub = data_1_sub.append(data_m_sub, ignore_index=True)
#
# data_1_sub['Month'] = [x[:2] for x in data_1_sub['Date']]
# Midnight = ["01", "02", '03', '04', '05', '06']
# # Hours_str = str(Hours)
# # print(Hours_str)
# # Hours = ['1', '2', '3', '4', '5', '6', '7', '8', '10', '11', '12']
# df = data_1_sub
# df['Hour'] = [x[:2] for x in data_1_sub['Time']]
# df['Hour'] = df['Hour'].astype(int)
# df_1 = df[(df['Hour'] <= 5) & (df['Hour'] >= 0)]
# df_1['Slot'] = 'Midnight'
# df_all_22 = df_1
# df_2 = df[(df['Hour'] <= 11) & (df['Hour'] >= 6)]
# df_2['Slot'] = 'Morning'
# df_all_22 = df_all_22.append(df_2, ignore_index=True)
#
# df_3 = df[(df['Hour'] <= 17) & (df['Hour'] >= 12)]
# df_3['Slot'] = 'Afternoon'
# df_all_22 = df_all_22.append(df_3, ignore_index=True)
#
# df_4 = df[(df['Hour'] <= 23) & (df['Hour'] >= 18)]
# df_4['Slot'] = 'Evening'
# df_all_22 = df_all_22.append(df_4, ignore_index=True)
#
# df_m_22 = [df_1, df_2, df_3, df_4]
# potential_22, x_22, y_22 = setBoundary(df_all=df_all_22, df_m=df_m_22)

# df1_1 = data_gtd[data_gtd[feature] == most_type[0]].sample(n=N).reset_index()
# df1_all = df1_1
# df1_2 = data_gtd[data_gtd[feature] == most_type[1]].sample(n=N).reset_index()
# df1_all = df1_all.append(df1_2, ignore_index=True)
# df1_3 = data_gtd[data_gtd[feature] == most_type[2]].sample(n=N).reset_index()
# df1_all = df1_all.append(df1_3, ignore_index=True)
# df1_4 = data_gtd[data_gtd[feature] == most_type[3]].sample(n=N).reset_index()
# df1_all = df1_all.append(df1_4, ignore_index=True)
# df1_m = [df1_1, df1_2, df1_3]
# # the number of colors need to excess n_groups
# colors = ['tab:blue', 'tab:red', 'tab:green', 'tab:yellow', 'tab: orange']
#
# po, x, y = setBoundary(df_all=df1_all, df_m=df1_m)
#
# z1 = np.transpose(po[:, :, 0]).tolist()
# z2 = np.transpose(po[:, :, 1]).tolist()
# x1 = x[:, 0].tolist()
# y1 = y[:, 0].tolist()

# kinds = data_gtd[feature].unique().tolist()
# # print(kinds)
#
# count = []
# # n = len(data_gtd[data_gtd['Category'] == 'WEAPON LAWS'])
# # print(n)
# for t in kinds:
#     n = len(data_gtd[data_gtd[feature] == t])
#     count.append(n)
# # print(count)
# most_type = []
# for i in range(n_groups):
#     m = count.index(max(count))
#     most_type.append(kinds[m])
#     count[m] = 0
#
# # a = count.index(max(count))
# print(most_type)
# df1_1 = data_gtd[data_gtd[feature] == most_type[0]].sample(n=N).reset_index()
# df1_all = df1_1
# df1_2 = data_gtd[data_gtd[feature] == most_type[1]].sample(n=N).reset_index()
# df1_all = df1_all.append(df1_2, ignore_index=True)
# df1_3 = data_gtd[data_gtd[feature] == most_type[2]].sample(n=N).reset_index()
# df1_all = df1_all.append(df1_3, ignore_index=True)
# df1_4 = data_gtd[data_gtd[feature] == most_type[3]].sample(n=N).reset_index()
# df1_all = df1_all.append(df1_4, ignore_index=True)
# df1_m = [df1_1, df1_2, df1_3]
# # the number of colors need to excess n_groups
# colors = ['tab:blue', 'tab:red', 'tab:green', 'tab:yellow', 'tab: orange']
#
# po, x, y = setBoundary(df_all=df1_all, df_m=df1_m)
#
# z1 = np.transpose(po[:, :, 0]).tolist()
# z2 = np.transpose(po[:, :, 1]).tolist()
# x1 = x[:, 0].tolist()
# y1 = y[:, 0].tolist()

# indicator: Domestic or International


gtd_features = [feature, feature2]
SF_features = ['Category', 'Slot']

# ==================================== Dash setting ==================================

external_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)

app.layout = html.Div(children=[

    html.Div(children='ECS 272 Final Project: Bubble Sets',
             style={'text-align': 'center',
                    'color': 'rgb(119, 119, 119)',
                    'font-family': 'Courier New, monospace',
                    'font-size': '40px',
                    'padding-top': '50px',
                    }
             ),

    html.Div(children='Group member: Jingwei Wan & Mingye Fu & Hang Su',
             style={'text-align': 'center',
                    'color': 'rgb(119, 119, 119)',
                    'font-family': 'FreeMono, monospace',
                    'font-size': '20px',
                    'width': '60%',
                    'padding-top': '100px',
                    'margin': 'auto',
                    'padding-bottom': '50px',
                    }
             ),

    html.Div(
        children='Here we performed bubble sets visualization on two datasets. One is the San Francisco City crime record in 2016,' +
                 'the other is the terrorism distribution in the USA in recent 50 years.' + 'Beside the algorithm used in the paper we chose.' +
                 'we also applied A star searching algorithm to find the optimal path between the bubble sets. One thing is that the datasets we used ' +
                 'are very huge. Thus we picked 80 data points randomly in each figure to demo our bubble sets visulaization.',
        style={'color': 'rgb(119, 119, 119)',
               'font-family': 'Courier New, monospace',
               'font-size': '20px',
               'width': '60%',
               'padding-top': '0px',
               'margin': 'auto',
               'padding-bottom': '0px',
               }
    ),

    html.Div([
        dcc.Dropdown(
            id='gtd_twist',
            options=[{'label': i, 'value': i} for i in gtd_features],
            value='attacktype1_txt'
        )
    ],
        style={'width': '30%',
               'padding-top': '50px',
               'margin': 'auto',
               'font-family': 'FreeMono, monospace'
               }
    ),
    html.Div(
        dcc.Graph(
            id='fig_gtd_twist'),
        style={  # 'overflow': 'auto',
            # 'text-align': 'center',
            'width': '55%',
            'margin': 'auto',
        }
    ),

    html.Div([
        dcc.Dropdown(
            id='gtd_A',
            options=[{'label': i, 'value': i} for i in gtd_features],
            value='attacktype1_txt'
        )
    ],
        style={'width': '30%',
               'padding-top': '50px',
               'margin': 'auto',
               'font-family': 'FreeMono, monospace'}
    ),

    html.Div(
        dcc.Graph(
            id='fig_gtd_A'),
        style={  # 'overflow': 'auto',
            # 'text-align': 'center',
            'width': '55%',
            'margin': 'auto',
        }
    ),

    html.Div([
        dcc.Dropdown(
            id='SF_twist',
            options=[{'label': i, 'value': i} for i in SF_features],
            value='Category'
        )
    ],
        style={'width': '30%',
               'padding-top': '50px',
               'margin': 'auto',
               'font-family': 'FreeMono, monospace'}
    ),

    html.Div(
        dcc.Graph(
            id='fig_SF_twist'),
        style={  # 'overflow': 'auto',
            # 'text-align': 'center',
            'width': '55%',
            'margin': 'auto',
        }
    ),

    html.Div([
        dcc.Dropdown(
            id='SF_A',
            options=[{'label': i, 'value': i} for i in SF_features],
            value='Category'
        )
    ],
        style={'width': '30%',
               'padding-top': '50px',
               'margin': 'auto',
               'font-family': 'FreeMono, monospace'}
    ),
    html.Div(
        dcc.Graph(
            id='fig_SF_A'),
        style={  # 'overflow': 'auto',
            # 'text-align': 'center',
            'width': '55%',
            'margin': 'auto',
        }
    ),

])


# The first graph: gtd in USA based on target and type
@app.callback(
    Output('fig_gtd_twist', 'figure'),
    [Input('gtd_twist', 'value')])
def update_graph(gtd_twist):
    # df_all_11, df_m_11, most_type_11 = get_df(dataset=data_gtd, feature='attacktype1_txt', n_groups=n_groups)
    # potential_11, x_11, y_11 = setBoundary(df_all=df_all_11, df_m=df_m_11)
    # Import data to use
    if gtd_twist == 'attacktype1_txt':
        df_all = df_all_11
        df_m = df_m_11
        types = most_type_11
        potentials = potential_11
        x = x_11
        y = y_11
    else:
        df_all = df_all_12
        df_m = df_m_12
        types = most_type_12
        potentials = potential_12
        x = x_12
        y = y_12
    x_min = df_all['X'].min()
    x_max = df_all['X'].max()
    gap_x = x_max - x_min
    y_min = df_all['Y'].min()
    y_max = df_all['Y'].max()
    gap_y = y_max - y_min
    x_line = [x_min, x_min + gap_x * 0.25, x_min + gap_x * 0.5, x_min + gap_x * 0.75, x_max]
    y_line = [y_min, y_min + gap_y * 0.25, y_min + gap_y * 0.5, y_min + gap_y * 0.75, y_max]

    traces = []
    colors_contour = ['blue', 'red', 'green', 'orange']
    for i in range(n_groups):
        z = potentials[:, :, i]
        x1 = x[:, i].tolist()
        y1 = y[:, i].tolist()
        trace1 = go.Contour(z=z, colorscale=[[0, 'rgba(256,256,256, 0)'], [0.8, colors_contour[i]], [1, 'rgba(0,0,0,0)']],
                            contours=dict(start=1, end=15, size=14),
                            opacity=0.5, showscale=False,
                            reversescale=False)
        trace2 = go.Scatter(x=y1, y=x1, opacity=0.8, mode='markers', name=types[i],
                            marker=dict(size=15, color=colors_contour[i]))
        traces.append(trace1)
        traces.append(trace2)
    layout = {
        'title': 'Terrorism in the USA distribution (1970 - 2017) by twisted middle points',
        'height': 800,
        'xaxis': {
            'title': 'Longitude',
            'ticks': 'outside',
            'ticktext': x_line,
            'tickvals': [(k - 1) * YboardScale / (5 - 1) for k in range(1, 6)],
            # 'ticktext': [str(df_all['Y'].min()), str(df_all['Y'].max())],
            "tickfont": {
                "size": 11,
                "color": "rgb(107, 107, 107)"
            },
            "tickwidth": 1,
            "showticklabels": True
        },
        'yaxis': {
            'title': 'Latitude',
            'ticks': 'outside',
            'ticktext': y_line,
            'tickvals': [(k - 1) * XboardScale / (5 - 1) for k in range(1, 6)],
            "tickfont": {
                "size": 11,
                "color": "rgb(107, 107, 107)"
            },
            "tickwidth": 1,
            "showticklabels": True
        },
    }
    fig1 = go.Figure(data=traces, layout=layout)
    fig1.update_layout(
        plot_bgcolor='rgba(0, 0, 0, 0)',
        paper_bgcolor='rgba(0, 0, 0, 0)',
    )
    return fig1


# The first graph: gtd in USA based on target and type, A*


@app.callback(
    Output('fig_gtd_A', 'figure'),
    [Input('gtd_A', 'value')])
def update_graph(gtd_A):
    # df_all_11, df_m_11, most_type_11 = get_df(dataset=data_gtd, feature='attacktype1_txt', n_groups=n_groups)
    # potential_11, x_11, y_11 = setBoundary(df_all=df_all_11, df_m=df_m_11)
    # Import data to use
    if gtd_A == 'attacktype1_txt':
        df_all = df_all_11
        df_m = df_m_11
        types = most_type_11
        potentials = potential_A_11
        x = x_A_11
        y = y_A_11
    else:
        df_all = df_all_12
        df_m = df_m_12
        types = most_type_12
        potentials = potential_A_12
        x = x_A_12
        y = y_A_12
    x_min = df_all['X'].min()
    x_max = df_all['X'].max()
    gap_x = x_max - x_min
    y_min = df_all['Y'].min()
    y_max = df_all['Y'].max()
    gap_y = y_max - y_min
    x_line = [x_min, x_min + gap_x * 0.25, x_min + gap_x * 0.5, x_min + gap_x * 0.75, x_max]
    y_line = [y_min, y_min + gap_y * 0.25, y_min + gap_y * 0.5, y_min + gap_y * 0.75, y_max]
    traces = []
    colors_contour = ['blue', 'red', 'green', 'orange']
    for i in range(n_groups):
        z = potentials[:, :, i]
        x1 = x[:, i].tolist()
        y1 = y[:, i].tolist()
        trace1 = go.Contour(z=z, colorscale=[[0, 'rgba(255,255,255, 0)'], [0.8, colors_contour[i]], [1.0, 'rgba(0,0,0,0)']],
                            contours=dict(start=1.5, end=15, size=13.5),
                            opacity=0.5, showscale=False,
                            reversescale=False)
        trace2 = go.Scatter(x=y1, y=x1, opacity=0.8, mode='markers', name=types[i],
                            marker=dict(size=15, color=colors_contour[i]))
        traces.append(trace1)
        traces.append(trace2)
    layout = {
        'title': 'Terrorism in the USA distribution (1970 - 2017) by A star algorithm',
        'height': 800,
        'xaxis': {
            'title': 'Longitude',
            'ticks': 'outside',
            'ticktext': x_line,
            'tickvals': [(k - 1) * YboardScale / (5 - 1) for k in range(1, 6)],
            # 'ticktext': [str(df_all['Y'].min()), str(df_all['Y'].max())],
            "tickfont": {
                "size": 11,
                "color": "rgb(107, 107, 107)"
            },
            "tickwidth": 1,
            "showticklabels": True
        },
        'yaxis': {
            'title': 'Latitude',
            'ticks': 'outside',
            'ticktext': y_line,
            'tickvals': [(k - 1) * XboardScale / (5 - 1) for k in range(1, 6)],
            "tickfont": {
                "size": 11,
                "color": "rgb(107, 107, 107)"
            },
            "tickwidth": 1,
            "showticklabels": True
        },
    }
    fig11 = go.Figure(data=traces, layout=layout)
    fig11.update_layout(
        plot_bgcolor='rgba(0, 0, 0, 0)',
        paper_bgcolor='rgba(0, 0, 0, 0)',
    )
    return fig11

    # dff = data[data['Domestic_International'] == Dome_Inte]
    # keys1 = ['Terminal']
    # groups1 = dff.groupby(keys1, as_index=keys1, sort=False)
    # result1 = groups1['Passenger_Count'].mean().to_frame().reset_index()
    #
    # x = result1['Terminal']
    # y = result1['Passenger_Count']
    # xy = zip(x, y)
    # xy = sorted(xy)
    # x_sorted = [x for x, y in xy]
    # y_sorted = [y for x, y in xy]

    # plot the average number of passengers of each terminal


# The second graph: SF crime based on time slot and category
@app.callback(
    Output('fig_SF_twist', 'figure'),
    [Input('SF_twist', 'value')])
def update_graph(SF_twist):
    # df_all_11, df_m_11, most_type_11 = get_df(dataset=data_gtd, feature='attacktype1_txt', n_groups=n_groups)
    # potential_11, x_11, y_11 = setBoundary(df_all=df_all_11, df_m=df_m_11)
    # Import data to use
    if SF_twist == 'Category':
        df_all = df_all_21
        df_m = df_m_21
        types = most_type_21
        potentials = potential_21
        x = x_21
        y = y_21
    else:
        df_all = df_all_22
        df_m = df_m_22
        types = most_type_22
        potentials = potential_22
        x = x_22
        y = y_22
    x_min = df_all['X'].min()
    x_max = df_all['X'].max()
    gap_x = x_max - x_min
    y_min = df_all['Y'].min()
    y_max = df_all['Y'].max()
    gap_y = y_max - y_min
    x_line = [x_min, x_min + gap_x * 0.25, x_min + gap_x * 0.5, x_min + gap_x * 0.75, x_max]
    y_line = [y_min, y_min + gap_y * 0.25, y_min + gap_y * 0.5, y_min + gap_y * 0.75, y_max]
    traces = []
    colors_contour = ['blue', 'red', 'green', 'orange']
    for i in range(n_groups):
        z = potentials[:, :, i]
        x1 = x[:, i].tolist()
        y1 = y[:, i].tolist()
        trace1 = go.Contour(z=z, colorscale=[[0, 'rgba(255,255,255, 0)'], [0.8, colors_contour[i]], [1.0, 'rgba(0,0,0,0)']],
                            contours=dict(start=1, end=15, size=14),
                            opacity=0.5, showscale=False,
                            reversescale=False)
        trace2 = go.Scatter(x=y1, y=x1, opacity=0.8, mode='markers', name=types[i],
                            marker=dict(size=15, color=colors_contour[i]))
        traces.append(trace1)
        traces.append(trace2)
    layout = {
        'title': 'San Francisco Crime record in 2016 by twisted middle points',
        'height': 800,
        'xaxis': {
            'title': 'Longitude',
            'ticks': 'outside',
            'ticktext': x_line,
            'tickvals': [(k - 1) * YboardScale / (5 - 1) for k in range(1, 6)],
            # 'ticktext': [str(df_all['Y'].min()), str(df_all['Y'].max())],
            "tickfont": {
                "size": 11,
                "color": "rgb(107, 107, 107)"
            },
            "tickwidth": 1,
            "showticklabels": True
        },
        'yaxis': {
            'title': 'Latitude',
            'ticks': 'outside',
            'ticktext': y_line,
            'tickvals': [(k - 1) * XboardScale / (5 - 1) for k in range(1, 6)],
            "tickfont": {
                "size": 11,
                "color": "rgb(107, 107, 107)"
            },
            "tickwidth": 1,
            "showticklabels": True
        },
    }
    fig2 = go.Figure(data=traces, layout=layout)
    fig2.update_layout(
        plot_bgcolor='rgba(0, 0, 0, 0)',
        paper_bgcolor='rgba(0, 0, 0, 0)',
    )
    return fig2


@app.callback(
    Output('fig_SF_A', 'figure'),
    [Input('SF_A', 'value')])
def update_graph(SF_A):
    # df_all_11, df_m_11, most_type_11 = get_df(dataset=data_gtd, feature='attacktype1_txt', n_groups=n_groups)
    # potential_11, x_11, y_11 = setBoundary(df_all=df_all_11, df_m=df_m_11)
    # Import data to use
    if SF_A == 'Category':
        df_all = df_all_21
        df_m = df_m_21
        types = most_type_21
        potentials = potential_A_21
        x = x_A_21
        y = y_A_21
    else:
        df_all = df_all_22
        df_m = df_m_22
        types = most_type_22
        potentials = potential_A_22
        x = x_A_22
        y = y_A_22
    x_min = df_all['X'].min()
    x_max = df_all['X'].max()
    gap_x = x_max - x_min
    y_min = df_all['Y'].min()
    y_max = df_all['Y'].max()
    gap_y = y_max - y_min
    x_line = [x_min, x_min + gap_x * 0.25, x_min + gap_x * 0.5, x_min + gap_x * 0.75, x_max]
    y_line = [y_min, y_min + gap_y * 0.25, y_min + gap_y * 0.5, y_min + gap_y * 0.75, y_max]
    traces = []
    colors_contour = ['blue', 'red', 'green', 'orange']
    for i in range(n_groups):
        z = potentials[:, :, i]
        x1 = x[:, i].tolist()
        y1 = y[:, i].tolist()
        trace1 = go.Contour(z=z, colorscale=[[0, 'rgba(255,255,255, 0)'], [0.8, colors_contour[i]], [1.0, 'rgba(0,0,0,0)']],
                            contours=dict(start=1, end=15, size=14),
                            opacity=0.5, showscale=False,
                            reversescale=False)
        trace2 = go.Scatter(x=y1, y=x1, opacity=0.8, mode='markers', name=types[i],
                            marker=dict(size=15, color=colors_contour[i]))
        traces.append(trace1)
        traces.append(trace2)
    layout = {
        'title': 'San Francisco Crime record in 2016 by A star algorithm',
        'height': 800,
        'xaxis': {
            'title': 'Longitude',
            'ticks': 'outside',
            'ticktext': x_line,
            'tickvals': [(k - 1) * YboardScale / (5 - 1) for k in range(1, 6)],
            # 'ticktext': [str(df_all['Y'].min()), str(df_all['Y'].max())],
            "tickfont": {
                "size": 11,
                "color": "rgb(107, 107, 107)"
            },
            "tickwidth": 1,
            "showticklabels": True
        },
        'yaxis': {
            'title': 'Latitude',
            'ticks': 'outside',
            'ticktext': y_line,
            'tickvals': [(k - 1) * XboardScale / (5 - 1) for k in range(1, 6)],
            "tickfont": {
                "size": 11,
                "color": "rgb(107, 107, 107)"
            },
            "tickwidth": 1,
            "showticklabels": True
        },
    }
    fig22 = go.Figure(data=traces, layout=layout)
    fig22.update_layout(
        plot_bgcolor='rgba(0, 0, 0, 0)',
        paper_bgcolor='rgba(0, 0, 0, 0)',
    )
    return fig22


if __name__ == '__main__':
    app.run_server(debug=True)
