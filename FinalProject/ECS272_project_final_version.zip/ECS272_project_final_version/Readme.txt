Instructions:

You just need to run "interactive_system.py" and then you will get the visualization result.