import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import normalize
from skimage import measure
import pandas as pd
from bubbleBoundary_twisted_middle_points import *
from bubbleBoundary3_new_input import *
import plotly.graph_objects as go
import dash
import dash_core_components as dcc
import dash_html_components as html
import urllib.request as req
from dash.dependencies import Input, Output

# save numpy array as csv file
from numpy import asarray
from numpy import savetxt

np.seterr(divide='ignore', invalid='ignore')

feature = 'attacktype1_txt'
feature2 = 'targtype1_txt'
XboardScale = 400
YboardScale = 300
N = 20
# M = 20


n_groups = 4

np.seterr(divide='ignore', invalid='ignore')

# load the data_gtdset from data_gtd server
data_gtd = pd.read_csv('gtd.csv', encoding='ISO-8859-1')
data_gtd = data_gtd[data_gtd['latitude'].notna()]
data_gtd = data_gtd[data_gtd['longitude'].notna()]
# Prepcocessing of data_gtd, dropping data_gtd with missing value
data_gtd = data_gtd.dropna(axis='columns')
# print(data_gtd[feature])
data_gtd = data_gtd[data_gtd['country_txt'] == 'United States'].reset_index()
data_gtd.rename(columns={'latitude': 'Y', 'longitude': 'X'}, inplace=True)

# Dataset of SF crime
data_SF = pd.read_csv('SF_crime.csv')
data_SF = data_SF.dropna()
data_SF['Date'] = data_SF['Date'].astype(str)
data_SF['Time'] = data_SF['Time'].astype(str)
data_SF['Hour'] = [x[:2] for x in data_SF['Time']]
data_SF['Hour'] = data_SF['Hour'].astype(int)


# Get data for plotting in advance
def get_df(dataset, feature, n_groups):
    df_m = []
    kinds = dataset[feature].unique().tolist()
    count = []
    for t in kinds:
        n = len(dataset[dataset[feature] == t])
        count.append(n)
    most_type = []
    for i in range(n_groups):
        m = count.index(max(count))
        most_type.append(kinds[m])
        count[m] = 0
    print(feature, most_type)
    df_1 = dataset[dataset[feature] == most_type[0]].sample(n=N).reset_index()
    df_m.append(df_1)
    df_all = df_1
    for k in np.arange(1, n_groups):
        df_sub = dataset[dataset[feature] == most_type[k]].sample(n=N).reset_index()
        df_all = df_all.append(df_sub, ignore_index=True)
        df_m.append(df_sub)

    # potential, x, y = setBoundary(df_all=df_all, df_m=df_m)

    return df_all, df_m, most_type


# Data_gtd: 'attacktype1_txt'
df_all_11, df_m_11, most_type_11 = get_df(dataset=data_gtd, feature='attacktype1_txt', n_groups=n_groups)
potential_11, x_11, y_11 = setBoundary(df_all=df_all_11, df_m=df_m_11)
potential_A_11, x_A_11, y_A_11 = setBoundary_A(df_all=df_all_11, df_m=df_m_11)
most_types = [most_type_11]

# Data_gtd: 'targtype1_txt'
df_all_12, df_m_12, most_type_12 = get_df(dataset=data_gtd, feature='targtype1_txt',
                                          n_groups=n_groups)
potential_12, x_12, y_12 = setBoundary(df_all=df_all_12, df_m=df_m_12)
potential_A_12, x_A_12, y_A_12 = setBoundary_A(df_all=df_all_12, df_m=df_m_12)
most_types.append(most_type_12)
# Data_SF: 'Category'
df_all_21, df_m_21, most_type_21 = get_df(dataset=data_SF, feature='Category',
                                          n_groups=n_groups)
potential_21, x_21, y_21 = setBoundary(df_all=df_all_21, df_m=df_m_21)
potential_A_21, x_A_21, y_A_21 = setBoundary_A(df_all=df_all_21, df_m=df_m_21)
most_types.append(most_type_21)
# Data_SF: 'Slot'
# Midnight Slot
data_1 = data_SF[(data_SF['Hour'] <= 5) & (data_SF['Hour'] >= 0)]
df_1 = data_1.sample(n=N).reset_index()
df_1['Slot'] = 'Midnight'
df_all_22 = df_1
# Morning Slot
data_1 = data_SF[(data_SF['Hour'] <= 11) & (data_SF['Hour'] >= 6)]
df_2 = data_1.sample(n=N).reset_index()
df_2['Slot'] = 'Morning'
df_all_22 = df_all_22.append(df_2, ignore_index=True)
# Afternoon Slot
data_1 = data_SF[(data_SF['Hour'] <= 17) & (data_SF['Hour'] >= 12)]
df_3 = data_1.sample(n=N).reset_index()
df_3['Slot'] = 'Afternoon'
df_all_22 = df_all_22.append(df_3, ignore_index=True)
# Evening Slot
data_1 = data_SF[(data_SF['Hour'] <= 23) & (data_SF['Hour'] >= 18)]
df_4 = data_1.sample(n=N).reset_index()
df_4['Slot'] = 'Evening'
df_all_22 = df_all_22.append(df_4, ignore_index=True)
df_m_22 = [df_1, df_2, df_3, df_4]
potential_22, x_22, y_22 = setBoundary(df_all=df_all_22, df_m=df_m_22)
potential_A_22, x_A_22, y_A_22 = setBoundary_A(df_all=df_all_22, df_m=df_m_22)
most_type_22 = ['Midnight', 'Morning', 'Afternoon', 'Evening']
most_types.append(most_type_22)

# sa_data_11 = [df_all_11, df_m_11, most_type_11, potential_11, x_11, y_11]
# sa_data_11 = np.asarray(sa_data_11)
# save to csv file
for i in range(4):
    savetxt('potential_11_' + str(i) + '.csv', potential_11[:, :, i])
    savetxt('potential_12_' + str(i) + '.csv', potential_12[:, :, i])
    savetxt('potential_21_' + str(i) + '.csv', potential_21[:, :, i])
    savetxt('potential_22_' + str(i) + '.csv', potential_22[:, :, i])
    savetxt('potential_A_11_' + str(i) + '.csv', potential_A_11[:, :, i])
    savetxt('potential_A_12_' + str(i) + '.csv', potential_A_12[:, :, i])
    savetxt('potential_A_21_' + str(i) + '.csv', potential_A_21[:, :, i])
    savetxt('potential_A_22_' + str(i) + '.csv', potential_A_22[:, :, i])

savetxt('x_11.csv', x_11)
savetxt('y_11.csv', y_11)
savetxt('x_12.csv', x_12)
savetxt('y_12.csv', y_12)
savetxt('x_21.csv', x_21)
savetxt('y_21.csv', y_21)
savetxt('x_22.csv', x_22)
savetxt('y_22.csv', y_22)
savetxt('x_A_11.csv', x_11)
savetxt('y_A_11.csv', y_11)
savetxt('x_A_12.csv', x_12)
savetxt('y_A_12.csv', y_12)
savetxt('x_A_21.csv', x_21)
savetxt('y_A_21.csv', y_21)
savetxt('x_A_22.csv', x_22)
savetxt('y_A_22.csv', y_22)

# savetxt('data11_1.csv', potential_11[:, :, 0])
# data_1 = data_SF[data_SF['Date'].str.startswith('01') == True]
# # print(len(data_1))
# data_1_sub = data_1.sample(n=7).reset_index()
# # print(data_1_sub)
# Months = ['02', '03', '04', '05', '06', '07', '08', '09', '10', '11', '12']
# for m in Months:
#     data_m = data_SF[data_SF['Date'].str.startswith(m) == True]
#     data_m_sub = data_m.sample(n=7).reset_index()
#     data_1_sub = data_1_sub.append(data_m_sub, ignore_index=True)
#
# data_1_sub['Month'] = [x[:2] for x in data_1_sub['Date']]
# Midnight = ["01", "02", '03', '04', '05', '06']
# # Hours_str = str(Hours)
# # print(Hours_str)
# # Hours = ['1', '2', '3', '4', '5', '6', '7', '8', '10', '11', '12']
# df = data_1_sub
# df['Hour'] = [x[:2] for x in data_1_sub['Time']]
# df['Hour'] = df['Hour'].astype(int)
# df_1 = df[(df['Hour'] <= 5) & (df['Hour'] >= 0)]
# df_1['Slot'] = 'Midnight'
# df_all_22 = df_1
# df_2 = df[(df['Hour'] <= 11) & (df['Hour'] >= 6)]
# df_2['Slot'] = 'Morning'
# df_all_22 = df_all_22.append(df_2, ignore_index=True)
#
# df_3 = df[(df['Hour'] <= 17) & (df['Hour'] >= 12)]
# df_3['Slot'] = 'Afternoon'
# df_all_22 = df_all_22.append(df_3, ignore_index=True)
#
# df_4 = df[(df['Hour'] <= 23) & (df['Hour'] >= 18)]
# df_4['Slot'] = 'Evening'
# df_all_22 = df_all_22.append(df_4, ignore_index=True)
#
# df_m_22 = [df_1, df_2, df_3, df_4]
# potential_22, x_22, y_22 = setBoundary(df_all=df_all_22, df_m=df_m_22)

# df1_1 = data_gtd[data_gtd[feature] == most_type[0]].sample(n=N).reset_index()
# df1_all = df1_1
# df1_2 = data_gtd[data_gtd[feature] == most_type[1]].sample(n=N).reset_index()
# df1_all = df1_all.append(df1_2, ignore_index=True)
# df1_3 = data_gtd[data_gtd[feature] == most_type[2]].sample(n=N).reset_index()
# df1_all = df1_all.append(df1_3, ignore_index=True)
# df1_4 = data_gtd[data_gtd[feature] == most_type[3]].sample(n=N).reset_index()
# df1_all = df1_all.append(df1_4, ignore_index=True)
# df1_m = [df1_1, df1_2, df1_3]
# # the number of colors need to excess n_groups
# colors = ['tab:blue', 'tab:red', 'tab:green', 'tab:yellow', 'tab: orange']
#
# po, x, y = setBoundary(df_all=df1_all, df_m=df1_m)
#
# z1 = np.transpose(po[:, :, 0]).tolist()
# z2 = np.transpose(po[:, :, 1]).tolist()
# x1 = x[:, 0].tolist()
# y1 = y[:, 0].tolist()

# kinds = data_gtd[feature].unique().tolist()
# # print(kinds)
#
# count = []
# # n = len(data_gtd[data_gtd['Category'] == 'WEAPON LAWS'])
# # print(n)
# for t in kinds:
#     n = len(data_gtd[data_gtd[feature] == t])
#     count.append(n)
# # print(count)
# most_type = []
# for i in range(n_groups):
#     m = count.index(max(count))
#     most_type.append(kinds[m])
#     count[m] = 0
#
# # a = count.index(max(count))
# print(most_type)
# df1_1 = data_gtd[data_gtd[feature] == most_type[0]].sample(n=N).reset_index()
# df1_all = df1_1
# df1_2 = data_gtd[data_gtd[feature] == most_type[1]].sample(n=N).reset_index()
# df1_all = df1_all.append(df1_2, ignore_index=True)
# df1_3 = data_gtd[data_gtd[feature] == most_type[2]].sample(n=N).reset_index()
# df1_all = df1_all.append(df1_3, ignore_index=True)
# df1_4 = data_gtd[data_gtd[feature] == most_type[3]].sample(n=N).reset_index()
# df1_all = df1_all.append(df1_4, ignore_index=True)
# df1_m = [df1_1, df1_2, df1_3]
# # the number of colors need to excess n_groups
# colors = ['tab:blue', 'tab:red', 'tab:green', 'tab:yellow', 'tab: orange']
#
# po, x, y = setBoundary(df_all=df1_all, df_m=df1_m)
#
# z1 = np.transpose(po[:, :, 0]).tolist()
# z2 = np.transpose(po[:, :, 1]).tolist()
# x1 = x[:, 0].tolist()
# y1 = y[:, 0].tolist()

# indicator: Domestic or International
