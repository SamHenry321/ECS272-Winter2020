from Algorithms import *
from Graph import *
from Tools import *


def a_star_search_example():
    start = (1,4)
    goal = (7,8)


    came_from, cost_so_far = a_star_search(diagram4, (1, 4), (7, 8))
    path = reconstruct_path(came_from, start, goal)
    print()
    draw_grid(diagram4, width=3, number=cost_so_far, start=start, goal=goal)
    draw_grid(diagram4, width=3, path = path)
    print(path)


if __name__ == '__main__':

    print('A Star')
    a_star_search_example()
