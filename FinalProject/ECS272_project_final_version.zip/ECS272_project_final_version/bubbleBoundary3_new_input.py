import numpy as np
import matplotlib.pyplot as plt
from sklearn.preprocessing import normalize
from skimage import measure
import pandas as pd
from Algorithms import *
from Graph import *
from Tools import *

feature = 'attacktype1_txt'
XboardScale = 400
YboardScale = 300
N = 20
# M = 20
RNode = 6.0
R2Node = 3.0
R1Node = 14.0
R0Node = 4.0
R1Edge = 12.0
R0Edge = 3.0
R0Node2 = 6.0
weightNode = 1
weightEdge = 0.8
weight2 = 0.3
buffer = 15
pointsOnLine = 55

n_groups = 4
'''
# load the dataset from data server
data = pd.read_csv('gtd.csv', encoding='ISO-8859-1')
data = data[data['latitude'].notna()]
data = data[data['longitude'].notna()]
# Prepcocessing of data, dropping data with missing value
data = data.dropna(axis='columns')
# print(data[feature])
data = data[data['country_txt'] == 'United States'].reset_index()
data.rename(columns={'latitude': 'Y', 'longitude': 'X'}, inplace=True)

# count = []
# # n = len(data[data['Category'] == 'WEAPON LAWS'])
# # print(n)
# kinds = data['country_txt'].unique().tolist()
# for t in kinds:
#     n = len(data[data['country_txt'] == t])
#     count.append(n)
# print(count)
#
# most_type = []
# for i in range(4):
#     m = count.index(max(count))
#     most_type.append(kinds[m])
#     count[m] = 0
# print(most_type)
# print(len(data))
# print(data)
# print(len(data[feature].unique()))

kinds = data[feature].unique().tolist()
# print(kinds)

count = []
# n = len(data[data['Category'] == 'WEAPON LAWS'])
# print(n)
for t in kinds:
    n = len(data[data[feature] == t])
    count.append(n)
# print(count)
most_type = []
for i in range(4):
    m = count.index(max(count))
    most_type.append(kinds[m])
    count[m] = 0

# a = count.index(max(count))
print(most_type)
df2_1 = data[data[feature] == most_type[0]].sample(n=N).reset_index()
df2_all = df2_1
df2_2 = data[data[feature] == most_type[1]].sample(n=N).reset_index()
df2_all = df2_all.append(df2_2, ignore_index=True)
df2_3 = data[data[feature] == most_type[2]].sample(n=N).reset_index()
df2_all = df2_all.append(df2_3, ignore_index=True)
df2_4 = data[data[feature] == most_type[3]].sample(n=N).reset_index()
df2_all = df2_all.append(df2_4, ignore_index=True)
df2_m = [df2_1, df2_2, df2_3, df2_4]
'''
# the number of colors need to excess n_groups
colors = ['tab:blue', 'tab:red', 'tab:green', 'tab:orange', 'tab:blue']


def pointsInitial_A(dataframe):
    # X = np.random.randint(XboardScale / 10, XboardScale * 9 / 10, size=(N, 1))
    # Y = np.random.randint(YboardScale / 10, YboardScale * 9 / 10, size=(N, 1))
    # x_min = df_1['X'].min()
    # x_max = df_1['X'].max()
    # y_min = df_1['Y'].min()
    # y_max = df_1['Y'].max()
    # step_x = (x_max - x_min) / XboardScale
    # step_y = (y_max - y_min) / YboardScale
    x_line = dataframe['X'].tolist()
    y_line = dataframe['Y'].tolist()
    return [x_line, y_line]


def setBoundary_A(df_all, df_m):
    # initialization
    xLists = np.zeros([N, n_groups], dtype=int)
    yLists = np.zeros([N, n_groups], dtype=int)
    potentials = np.zeros([XboardScale, YboardScale, n_groups], dtype=float)

    # Create data set
    x_min = df_all['X'].min()
    x_max = df_all['X'].max()
    y_min = df_all['Y'].min()
    y_max = df_all['Y'].max()
    step_x = (x_max - x_min) / (XboardScale * 0.8)
    step_y = (y_max - y_min) / (YboardScale * 0.8)

    for group in range(n_groups):
        line1 = pointsInitial_A(df_m[group])
        xList = []
        yList = []
        for x1 in line1[0]:
            increment = int(((x1 - x_min) / step_x) + 1 + XboardScale * 0.1)
            xList.append(increment)
        for y1 in line1[1]:
            increment = int(((y1 - y_min) / step_y) + 1 + YboardScale * 0.1)
            yList.append(increment)
        xList = np.asarray(xList)
        yList = np.asarray(yList)
        # pointsLoc = pointsInitial_A(df_all)
        xLists[:, group] = xList
        yLists[:, group] = yList

    # print(xLists)
    # print(yLists)

    # Calculate center point
    xCenter = np.mean(xLists[:, 0])
    yCenter = np.mean(yLists[:, 0])
    indexSorted = sorted(range(len(xLists[:, 0])),
                         key=lambda k: (xLists[k, 0] - xCenter) ** 2 + (yLists[k, 0] - yCenter) ** 2)
    xLists[:, 0] = xLists[indexSorted, 0]
    yLists[:, 0] = yLists[indexSorted, 0]

    # Plot scattering
    plt.figure(1)
    for group in range(n_groups):
        plt.plot(xLists[:, group], yLists[:, group], marker='o', markersize=5, color=colors[group], linestyle='')

    # Calcualte potential based on data
    for group in range(n_groups):
        xList = xLists[:, group]
        yList = yLists[:, group]
        xList2 = []
        yList2 = []
        for other_group in range(n_groups):
            if other_group != group:
                xList2 = np.append(xList2, xLists[:, other_group])
                yList2 = np.append(yList2, yLists[:, other_group])

        potentials[:, :, group] = potentialCal_A(xList, yList, xList2, yList2)

    fig, ax = plt.subplots()
    ax.imshow(np.transpose(potentials[:, :, 1]))

    # Plot coutour for two sets
    for group in range(n_groups):
        contour = measure.find_contours(np.transpose(potentials[:, :, group]), 0.8)
        for n, contour in enumerate(contour):
            plt.figure(1)
            plt.plot(contour[:, 1], contour[:, 0], linewidth=2, color=colors[group])
    return potentials, xLists, yLists


def potentialCal_A(xList, yList, xList2, yList2):
    N = len(xList)
    M = len(xList2)
    potential = np.zeros([XboardScale, YboardScale], dtype=float)

    edgeList = [[xList[1], yList[1], xList[0], yList[0]]]

    for i in range(2, N):
        tempXList = xList[0: i]
        tempYList = yList[0: i]
        indexNearest = sorted(range(i),
                              key=lambda k: (xList[i] - tempXList[k]) ** 2 + (yList[i] - tempYList[k]) ** 2)
        j = indexNearest[0]
        edgeList.append([xList[i], yList[i], xList[j], yList[j]])

    edgePointList = []

    # A* routing

    map = GridWithWeights(XboardScale, YboardScale)
    other_points = []
    walls = []
    mountains = []
    for x in range(XboardScale):
        for y in range(YboardScale):
            for i in range(len(xList2)):
                if x == xList2[i] and y == yList2[i]:
                    walls.append((x, y))
                elif abs(x - xList2[i]) <= RNode and abs(y - yList2[i]) <= RNode:
                    mountains.append((x, y))
    other_points = walls
    # map.walls = walls
    map.weights = {loc: 20 for loc in mountains}
    map.weights.update({loc: 50 for loc in walls})
    # draw_grid(map, width=1)

    print("Routing")

    # print(edgeList)

    for i in range(len(edgeList)):
        edgePoints = []
        start = (edgeList[i][0], edgeList[i][1])
        goal = (edgeList[i][2], edgeList[i][3])

        came_from, cost_so_far = a_star_search(map, start, goal)
        path = reconstruct_path(came_from, start, goal)

        for point in path:
            edgePoints.append([point[0], point[1]])
        edgePointList.append(edgePoints)

    edgePointList = np.array(edgePointList)

    print("Calculating potential")

    for i in range(len(edgeList)):
        print(i)
        for j in range(0, len(edgePointList[i])):
            if j == 0 or j == len(edgePointList[i]) - 1:
                R1 = R1Node
                R0 = R0Node
                weight = weightNode
            else:
                R1 = R1Edge
                R0 = R0Edge
                weight = weightEdge
            for x in range(np.int_(max(0, edgePointList[i][j][0] - R1)),
                           np.int_(min(edgePointList[i][j][0] + R1, XboardScale))):
                for y in range(np.int_(max(0, edgePointList[i][j][1] - R1)),
                               np.int_(min(edgePointList[i][j][1] + R1, YboardScale))):
                    disNode = np.sqrt(
                        (1.0 * x - edgePointList[i][j][0]) ** 2 + (1.0 * y - edgePointList[i][j][1]) ** 2)
                    if disNode < R1:
                        if disNode < R0:
                            potential[x, y] += weight
                        else:
                            potential[x, y] += weight * (R1 - disNode) ** 2 / (R1 - R0) ** 2

                        for wall in other_points:
                            x_wall = wall[0]
                            y_wall = wall[1]
                            if np.abs(x_wall - x) < R2Node and np.abs(y_wall - y) < R2Node:
                                dis = np.sqrt((1.0 * x - x_wall) ** 2 + (1.0 * y - y_wall) ** 2)
                                if dis < R2Node:
                                    potential[x, y] -= weight2 * (1 - (dis / R2Node) ** 2)

                        if potential[x, y] < 0:
                            potential[x, y] = 0

                        if potential[x, y] > 15:
                            potential[x, y] = 15

        # for j in range(len(edgePointList[i])):
        #     plt.figure(1)
        #     plt.plot(edgePointList[i][j][0], edgePointList[i][j][1],  color = 'black', marker = 'o')
    # plt.gca().invert_yaxis()
    potential[potential < 0] = 0
    return potential

# if __name__ == '__main__':
#     setBoundary_A(df_all=df2_all, df_m=df2_m)
#     plt.show()
